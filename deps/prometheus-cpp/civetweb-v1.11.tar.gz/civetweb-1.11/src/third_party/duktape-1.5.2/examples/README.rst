================
Duktape examples
================

Examples for using Duktape.  These support user documentation and are
intended as informative illustrations only.

Examples are unmaintained and are not production quality code.  Bugs are
not not necessarily fixed, unless the bug makes the example misleading
as documentation.
